package com.example.lunarss.nycfreewifi;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.channels.Pipe;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * This work is done by group 12.
 */

public class Read {

    /**
     * Constructor of the Read.
     */
    public Read() {
    }

    /**
     * Read the data from the dataset.
     * 
     * @param context - the context from map api main file.
     * @return - data from the dataset
     * @throws FileNotFoundException
     * @throws IOException
     */
    public String[][] read(Context context) throws FileNotFoundException, IOException {
        String fileName = "NYCfwhs.csv";
        InputStream is = context.getAssets().open(fileName);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        List<String> out = new ArrayList<>();
        String line;
        reader.readLine();
        while ((line = reader.readLine()) != null) {
            out.add(line);
        }
        System.out.println(out.toString());   //Prints the string content read from input stream
        reader.close();

        String[][] dataArr = new String[2061][3];
        for (int i = 0; i < out.size(); i++) {
            dataArr[i][0] = out.get(i).split(",")[0];
            dataArr[i][1] = out.get(i).split(",")[1];
            dataArr[i][2] = out.get(i).split(",")[2];
        }
        return dataArr;

    }

}
